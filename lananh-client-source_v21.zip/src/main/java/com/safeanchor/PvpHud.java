package com.safeanchor;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * PvP Visual & HUD - CHỈ HIỂN THỊ, không tự thao tác gì:
 *  - Explosion Damage HUD: ước tính số tim mất nếu End Crystal / Respawn Anchor trong tầm nổ ngay bây giờ.
 *  - Totem & Armor Alert: đếm Totem, cảnh báo khi hết Totem hoặc giáp dưới 20%.
 *  - Combat Info: Reach, Combo, CPS, hồi chiêu đòn đánh, hồi chiêu Ender Pearl.
 * Nhẹ: quét thưa theo tick (crystal 4 tick / anchor 10 tick), không mixin; module tắt là không chạy gì.
 */
public class PvpHud extends Module {
    record Est(String label, double dist, double dmg) {}

    final Setting.Check dmg = add(new Setting.Check("Sát thương nổ", true));
    final Setting.Check alert = add(new Setting.Check("Cảnh báo totem/giáp", true));
    final Setting.Check info = add(new Setting.Check("Combat info", true));
    final Setting.Slider totemMin = add(new Setting.Slider("Totem ≤", 2, 0, 6, 1));
    final Setting.Slider range = add(new Setting.Slider("Tầm quét", 12, 4, 24, 1));
    final Setting.Slider px = add(new Setting.Slider("X (%)", 2, 0, 100, 1));
    final Setting.Slider py = add(new Setting.Slider("Y (%)", 30, 0, 100, 1));

    static int combo; static long comboT;
    static double reach = -1; static long reachT;
    static final ArrayDeque<Long> clicks = new ArrayDeque<>();
    static boolean lastAtk; static int lastHurt, crystalT, anchorT;
    static final List<Est> ests = new ArrayList<>();
    static final List<Est> anchorEsts = new ArrayList<>();

    public PvpHud() { super("PvpHud", "Sát thương nổ, totem/giáp, combat", Cat.HUD); }

    // ---------- sự kiện đánh ----------
    public static void onAttack(PlayerEntity pl, Entity e) {
        long now = System.currentTimeMillis();
        reach = Util.distToBox(pl.getEyePos(), e.getBoundingBox()); reachT = now;
        combo = (now - comboT < 3000) ? combo + 1 : 1; comboT = now;
    }

    // ---------- ước tính sát thương nổ (công thức vanilla, chưa tính enchant giáp) ----------
    static double exposure(World w, Vec3d src, PlayerEntity p) {
        Box b = p.getBoundingBox();
        double dx = 1.0 / ((b.maxX - b.minX) * 2 + 1), dy = 1.0 / ((b.maxY - b.minY) * 2 + 1), dz = 1.0 / ((b.maxZ - b.minZ) * 2 + 1);
        double ox = (1 - Math.floor(1 / dx) * dx) / 2, oz = (1 - Math.floor(1 / dz) * dz) / 2;
        int hit = 0, total = 0;
        for (double x = 0; x <= 1; x += dx) for (double y = 0; y <= 1; y += dy) for (double z = 0; z <= 1; z += dz) {
            Vec3d pt = new Vec3d(MathHelper.lerp(x, b.minX, b.maxX) + ox, MathHelper.lerp(y, b.minY, b.maxY), MathHelper.lerp(z, b.minZ, b.maxZ) + oz);
            if (w.raycast(new RaycastContext(pt, src, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p)).getType() == HitResult.Type.MISS) hit++;
            total++;
        }
        return total == 0 ? 0 : (double) hit / total;
    }

    static double explosionDamage(MinecraftClient mc, PlayerEntity p, Vec3d src, float power) {
        double q = power * 2.0, dist = p.getPos().distanceTo(src) / q;
        if (dist > 1.0) return 0;
        double imp = (1.0 - dist) * exposure(mc.world, src, p);
        double d = (imp * imp + imp) / 2.0 * 7.0 * q + 1.0;
        switch (mc.world.getDifficulty()) { case PEACEFUL -> d = 0; case EASY -> d = Math.min(d / 2.0 + 1.0, d); case HARD -> d = d * 1.5; default -> { } }
        float armor = p.getArmor(), tough = (float) p.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS);
        float f = 2.0f + tough / 4.0f, g = MathHelper.clamp(armor - (float) d / f, armor * 0.2f, 20f);
        d *= 1.0 - g / 25.0;
        StatusEffectInstance res = p.getStatusEffect(StatusEffects.RESISTANCE);
        if (res != null) d *= Math.max(0, 1.0 - 0.2 * (res.getAmplifier() + 1));
        return Math.max(0, d);
    }

    // ---------- tick (chỉ chạy khi module bật) ----------
    @Override public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player; World w = mc.world;
        if (p == null || w == null) return;
        long now = System.currentTimeMillis();
        boolean atk = mc.options.attackKey.isPressed();
        if (atk && !lastAtk) clicks.add(now);
        lastAtk = atk;
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
        if (p.hurtTime > lastHurt) combo = 0;                       // bị đánh -> mất combo
        lastHurt = p.hurtTime;
        if (now - comboT > 3000) combo = 0;
        if (!dmg.get()) { ests.clear(); anchorEsts.clear(); return; }
        double r = range.get();
        if (--crystalT <= 0) {
            crystalT = 4; ests.clear();
            List<EndCrystalEntity> cs = new ArrayList<>(w.getEntitiesByClass(EndCrystalEntity.class, p.getBoundingBox().expand(r), e -> true));
            cs.sort(Comparator.comparingDouble(e -> e.squaredDistanceTo(p)));
            for (int i = 0; i < Math.min(3, cs.size()); i++) {
                EndCrystalEntity c = cs.get(i);
                ests.add(new Est("Crystal", c.distanceTo(p), explosionDamage(mc, p, c.getPos(), 6f)));
            }
        }
        if (--anchorT <= 0) {
            anchorT = 10; anchorEsts.clear();
            if (w.getRegistryKey() == World.NETHER) return;          // ở Nether anchor không nổ
            BlockPos pc = p.getBlockPos();
            int rr = (int) Math.min(8, r);
            BlockPos.Mutable m = new BlockPos.Mutable();
            for (int dx = -rr; dx <= rr && anchorEsts.size() < 3; dx++) for (int dy = -rr; dy <= rr; dy++) for (int dz = -rr; dz <= rr; dz++) {
                m.set(pc.getX() + dx, pc.getY() + dy, pc.getZ() + dz);
                var st = w.getBlockState(m);
                if (!st.isOf(Blocks.RESPAWN_ANCHOR) || st.get(Properties.CHARGES) < 1) continue;
                Vec3d c = Vec3d.ofCenter(m);
                anchorEsts.add(new Est("Anchor", c.distanceTo(p.getPos()), explosionDamage(mc, p, c, 5f)));
                if (anchorEsts.size() >= 3) break;
            }
        }
    }

    static int count(ClientPlayerEntity p, net.minecraft.item.Item it) {
        int n = 0;
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) { ItemStack s = inv.getStack(i); if (s.isOf(it)) n += s.getCount(); }
        return n;
    }

    // ---------- HUD ----------
    @Override public void onHud(DrawContext ctx, MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        List<String> lines = new ArrayList<>();
        double hp = p.getHealth() + p.getAbsorptionAmount();
        if (dmg.get()) {
            List<Est> all = new ArrayList<>(ests); all.addAll(anchorEsts);
            for (Est e : all) {
                String col = e.dmg() >= hp ? "§c" : e.dmg() >= hp * 0.5 ? "§e" : "§f";
                lines.add(col + e.label() + " " + (int) e.dist() + "m: -" + String.format("%.1f", e.dmg() / 2.0) + " ♥" + (e.dmg() >= hp ? " §4CHẾT" : ""));
            }
        }
        boolean warn = false;
        if (alert.get()) {
            int tot = count(p, Items.TOTEM_OF_UNDYING);
            if (tot == 0) { lines.add("§c⚠ HẾT TOTEM"); warn = true; }
            else if (tot <= totemMin.get()) { lines.add("§e⚠ Totem còn " + tot); }
            int worst = 100;
            for (ItemStack s : p.getInventory().armor) if (!s.isEmpty() && s.getMaxDamage() > 0) worst = Math.min(worst, 100 - s.getDamage() * 100 / s.getMaxDamage());
            if (worst < 20) { lines.add("§c⚠ Giáp " + worst + "%"); warn = true; }
        }
        if (info.get()) {
            long now = System.currentTimeMillis();
            lines.add("§7Reach: §f" + (reach >= 0 && now - reachT < 4000 ? String.format("%.2f", reach) : "-") + "  §7Combo: §f" + combo + "  §7CPS: §f" + clicks.size());
            lines.add("§7Đòn: §f" + (int) (p.getAttackCooldownProgress(0f) * 100) + "%  §7Pearl: " + pearl(p));
        }
        if (warn) {                                                  // viền đỏ nhẹ khi hết totem / giáp thấp
            int W = ctx.getScaledWindowWidth(), H = ctx.getScaledWindowHeight(), a = 0x50000000 | 0xFF0000;
            ctx.fill(0, 0, W, 2, a); ctx.fill(0, H - 2, W, H, a); ctx.fill(0, 0, 2, H, a); ctx.fill(W - 2, 0, W, H, a);
        }
        if (lines.isEmpty()) return;
        int x = (int) (ctx.getScaledWindowWidth() * px.get() / 100), y = (int) (ctx.getScaledWindowHeight() * py.get() / 100), w = 0;
        for (String l : lines) w = Math.max(w, mc.textRenderer.getWidth(l));
        ctx.fill(x - 3, y - 3, x + w + 3, y + lines.size() * 11 + 1, 0x90000000);
        for (int i = 0; i < lines.size(); i++) ctx.drawText(mc.textRenderer, lines.get(i), x, y + i * 11, 0xFFFFFFFF, true);
    }

    static String pearl(ClientPlayerEntity p) {
        float c = p.getItemCooldownManager().getCooldownProgress(new ItemStack(Items.ENDER_PEARL), 0f);
        return c > 0 ? "§c" + (int) (c * 100) + "%" : "§asẵn sàng";
    }
}
