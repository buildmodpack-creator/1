package com.safeanchor;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * Bảng "Xây dựng cơ sở" 3 cột (giống ảnh Raven): chọn block (tìm kiếm + lưới 2D), bảng màu, thông tin dựng (lớp, vật liệu).
 * Màn hình hẹp: 1 cột + thanh tab. Chuột phải / Esc để đóng, cuộn chuột trong lưới / bảng vật liệu / thanh lớp.
 */
public class BuilderScreen extends Screen {
    static final int RED = 0xFFE0262E, PANEL = 0xFF16161C, CARD = 0xFF1E1E26, TXT = 0xFFE8E8F0, DIM = 0xFF8A8A9A;
    static final String[] CHIPS = {"Tất cả", "Đá", "Gỗ", "Khối màu", "Phát sáng"};
    static final int[] SWATCH = {0xE0262E, 0xFF7A1A, 0xFFC83C, 0x4CD964, 0x2CD4D4, 0x3B82F6, 0x8B5CF6, 0xF472B6, 0xFFFFFF, 0x16161C};
    static List<Block> ALL;

    final Screen parent;
    TextFieldWidget search, hex;
    int tab = 0, chip = 0, gridScroll = 0, matScroll = 0, colorTarget = 0;   // colorTarget 0 = ghost, 1 = viền chunk
    float hh, hs, hv;
    final List<Block> shown = new ArrayList<>();
    final List<Object[]> hits = new ArrayList<>();        // {x, y, w, h, Runnable}
    final List<Object[]> drags = new ArrayList<>();       // {x, y, w, h, BiConsumer<Double,Double>}
    BiConsumer<Double, Double> activeDrag; int[] dragRect;

    public BuilderScreen(Screen parent) {
        super(Text.literal("Xây dựng cơ sở"));
        this.parent = parent;
        if (ALL == null) {
            ALL = new ArrayList<>();
            for (Block b : Registries.BLOCK) {
                String id = Registries.BLOCK.getId(b).getPath();
                if (b.asItem() == Items.AIR || id.contains("command_block") || id.equals("barrier") || id.equals("bedrock") || id.contains("structure") || id.equals("jigsaw") || id.equals("light") || id.contains("spawner")) continue;
                ALL.add(b);
            }
        }
    }

    // ---------- khởi tạo ----------
    @Override protected void init() {
        search = new TextFieldWidget(textRenderer, 0, 0, 100, 14, Text.literal(""));
        search.setPlaceholder(Text.literal("Tìm block... (vd: obsidian)"));
        search.setChangedListener(s -> { gridScroll = 0; refilter(); });
        addDrawableChild(search);
        hex = new TextFieldWidget(textRenderer, 0, 0, 60, 14, Text.literal(""));
        hex.setMaxLength(7);
        hex.setChangedListener(s -> { Integer v = parseHex(s); if (v != null && hex.isFocused()) { setColor(v, false); } });
        addDrawableChild(hex);
        loadTarget();
        refilter();
    }

    int curColor() { return colorTarget == 0 ? Config.I.bdGhostColor : Config.I.bdChunkColor; }

    void loadTarget() {
        float[] f = rgb2hsv(curColor()); hh = f[0]; hs = f[1]; hv = f[2];
        if (hex != null) hex.setText(String.format("#%06X", curColor() & 0xFFFFFF));
    }

    void setColor(int rgb, boolean updateHex) {
        if (colorTarget == 0) Config.I.bdGhostColor = rgb & 0xFFFFFF; else Config.I.bdChunkColor = rgb & 0xFFFFFF;
        if (updateHex && hex != null) hex.setText(String.format("#%06X", rgb & 0xFFFFFF));
        float[] f = rgb2hsv(rgb); if (f[1] > 0.001f && f[2] > 0.001f) hh = f[0]; hs = f[1]; hv = f[2];
    }

    static Integer parseHex(String s) {
        try { String t = s.startsWith("#") ? s.substring(1) : s; if (t.length() != 6) return null; return Integer.parseInt(t, 16); } catch (Exception e) { return null; }
    }

    static float[] rgb2hsv(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min, h;
        if (d == 0) h = 0; else if (max == r) h = ((g - b) / d) % 6; else if (max == g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
        h /= 6f; if (h < 0) h += 1;
        return new float[]{h, max == 0 ? 0 : d / max, max};
    }

    static int hsv2rgb(float h, float s, float v) {
        float c = v * s, hh = (h - (float) Math.floor(h)) * 6f, x = c * (1 - Math.abs(hh % 2 - 1)), m = v - c, r, g, b;
        int i = (int) hh;
        switch (i) { case 0 -> { r = c; g = x; b = 0; } case 1 -> { r = x; g = c; b = 0; } case 2 -> { r = 0; g = c; b = x; }
            case 3 -> { r = 0; g = x; b = c; } case 4 -> { r = x; g = 0; b = c; } default -> { r = c; g = 0; b = x; } }
        return (Math.round((r + m) * 255) << 16) | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }

    // ---------- lọc block ----------
    boolean inChip(Block b) {
        String id = Registries.BLOCK.getId(b).getPath();
        return switch (chip) {
            case 1 -> id.contains("stone") || id.contains("deepslate") || id.contains("cobble") || id.contains("brick") || id.contains("andesite") || id.contains("diorite")
                    || id.contains("granite") || id.contains("basalt") || id.contains("blackstone") || id.contains("tuff") || id.contains("obsidian") || id.contains("calcite") || id.contains("netherrack");
            case 2 -> id.contains("planks") || id.contains("log") || id.contains("wood") || id.contains("stem") || id.contains("hyphae") || id.contains("bamboo_block");
            case 3 -> id.contains("wool") || id.contains("concrete") || id.contains("terracotta") || id.contains("stained_glass");
            case 4 -> b.getDefaultState().getLuminance() > 0;
            default -> true;
        };
    }

    void refilter() {
        shown.clear();
        String q = search == null ? "" : search.getText().trim().toLowerCase();
        for (Block b : ALL) {
            if (!inChip(b)) continue;
            if (!q.isEmpty() && !Registries.BLOCK.getId(b).getPath().contains(q) && !b.getName().getString().toLowerCase().contains(q)) continue;
            shown.add(b);
        }
    }

    Block selected() {
        for (Block b : ALL) if (Registries.BLOCK.getId(b).getPath().equals(Config.I.bdSel)) return b;
        return net.minecraft.block.Blocks.OBSIDIAN;
    }

    // ---------- đăng ký vùng bấm / kéo ----------
    void hit(int x, int y, int w, int h, Runnable r) { hits.add(new Object[]{x, y, w, h, r}); }
    void drag(int x, int y, int w, int h, BiConsumer<Double, Double> fn) { drags.add(new Object[]{x, y, w, h, fn}); }
    static boolean in(Object[] o, double mx, double my) { return mx >= (int) o[0] && mx < (int) o[0] + (int) o[2] && my >= (int) o[1] && my < (int) o[1] + (int) o[3]; }

    // ---------- vẽ ----------
    void panel(DrawContext ctx, int x, int y, int w, int h, String title) {
        ctx.fill(x, y, x + w, y + h, PANEL);
        ctx.fill(x, y, x + w, y + 1, 0xFF2A2A34); ctx.fill(x, y + h - 1, x + w, y + h, 0xFF2A2A34);
        ctx.fill(x, y, x + 1, y + h, 0xFF2A2A34); ctx.fill(x + w - 1, y, x + w, y + h, 0xFF2A2A34);
        ctx.drawText(textRenderer, "§l" + title, x + 8, y + 7, TXT, false);
    }

    void pill(DrawContext ctx, int x, int y, boolean on) {
        ctx.fill(x, y, x + 22, y + 11, on ? RED : 0xFF3A3A46);
        int kx = on ? x + 12 : x + 1;
        ctx.fill(kx, y + 1, kx + 9, y + 10, 0xFFFFFFFF);
    }

    void btn(DrawContext ctx, int x, int y, int w, int h, String t, int bg, int mx, int my) {
        boolean hv2 = mx >= x && mx < x + w && my >= y && my < y + h;
        ctx.fill(x, y, x + w, y + h, hv2 ? (bg | 0xFF000000) + 0x101010 : bg);
        ctx.drawCenteredTextWithShadow(textRenderer, t, x + w / 2, y + (h - 8) / 2, TXT);
    }

    void slider(DrawContext ctx, int x, int y, int w, double frac, java.util.function.DoubleConsumer set) {
        ctx.fill(x, y + 3, x + w, y + 6, 0xFF3A3A46);
        ctx.fill(x, y + 3, x + (int) (w * frac), y + 6, RED);
        int kx = x + (int) (w * frac);
        ctx.fill(kx - 2, y, kx + 3, y + 9, 0xFFFFFFFF);
        drag(x - 3, y - 2, w + 6, 13, (fx, fy) -> set.accept(Math.max(0, Math.min(1, fx))));
    }

    @Override public void render(DrawContext ctx, int mx, int my, float d) {
        hits.clear(); drags.clear();
        MenuBg.draw(ctx, width, height, -200, 0);
        Config c = Config.I;
        TextRenderer tr = textRenderer;
        boolean wide = width >= 560;
        int m = 6, top = 24, bottom = height - 14;
        ctx.drawText(tr, "§lLAN ANH CLIENT", m, 8, 0xFFFFFFFF, false);
        ctx.drawText(tr, "§cBUILDER", m + tr.getWidth("LAN ANH CLIENT") + 10, 8, 0xFFFF5555, false);
        int px1, pw1, px2, pw2, px3, pw3;
        if (wide) {
            int tw = width - 4 * m;
            pw1 = (int) (tw * 0.42); pw2 = (int) (tw * 0.26); pw3 = tw - pw1 - pw2;
            px1 = m; px2 = px1 + pw1 + m; px3 = px2 + pw2 + m;
        } else {
            px1 = px2 = px3 = m; pw1 = pw2 = pw3 = width - 2 * m;
            top = 38;
            String[] tn = {"Chọn block", "Màu", "Thông tin"};
            int tx = m;
            for (int i = 0; i < 3; i++) {
                int w = tr.getWidth(tn[i]) + 14, ii = i;
                ctx.fill(tx, 22, tx + w, 34, tab == i ? RED : CARD);
                ctx.drawText(tr, tn[i], tx + 7, 25, TXT, false);
                hit(tx, 22, w, 12, () -> tab = ii);
                tx += w + 4;
            }
        }
        int ph = bottom - top;
        search.visible = false; hex.visible = false;
        if (wide || tab == 0) drawBlocks(ctx, px1, top, pw1, ph, mx, my);
        if (wide || tab == 1) drawColors(ctx, px2, top, pw2, ph, mx, my);
        if (wide || tab == 2) drawInfo(ctx, px3, top, pw3, ph, mx, my);
        ctx.drawText(tr, "§8BẤM: CHỌN  •  CUỘN: ĐỔI LỚP / CUỘN LƯỚI  •  ESC: ĐÓNG", m, height - 11, DIM, false);
        super.render(ctx, mx, my, d);
    }

    // ----- cột 1: chọn block -----
    void drawBlocks(DrawContext ctx, int x, int y, int w, int h, int mx, int my) {
        Config c = Config.I; TextRenderer tr = textRenderer;
        panel(ctx, x, y, w, h, "Xây dựng cơ sở");
        String st = c.bdOn ? "BẬT" : "TẮT";
        int pw = tr.getWidth(st) + 12;
        ctx.fill(x + w - pw - 8, y + 5, x + w - 8, y + 17, c.bdOn ? RED : 0xFF3A3A46);
        ctx.drawText(tr, st, x + w - pw - 2, y + 8, 0xFFFFFFFF, false);
        hit(x + w - pw - 8, y + 5, pw, 12, () -> { c.bdOn = !c.bdOn; Config.save(); });
        search.visible = true; search.setX(x + 8); search.setY(y + 22); search.setWidth(w - 16);
        // chips
        int cx = x + 8, cy = y + 40;
        for (int i = 0; i < CHIPS.length; i++) {
            int cw = tr.getWidth(CHIPS[i]) + 10, ii = i;
            if (cx + cw > x + w - 6) { cx = x + 8; cy += 14; }
            ctx.fill(cx, cy, cx + cw, cy + 12, chip == i ? RED : CARD);
            ctx.drawText(tr, CHIPS[i], cx + 5, cy + 2, TXT, false);
            hit(cx, cy, cw, 12, () -> { chip = ii; gridScroll = 0; refilter(); });
            cx += cw + 4;
        }
        int gy = cy + 18, gh = y + h - 62 - gy;
        int cols = Math.max(3, (w - 12) / 34), cell = (w - 12) / cols, rowH = cell + 9;
        int rows = Math.max(1, gh / rowH), total = (shown.size() + cols - 1) / cols;
        gridScroll = Math.max(0, Math.min(Math.max(0, total - rows), gridScroll));
        ctx.enableScissor(x + 4, gy, x + w - 4, gy + gh);
        String sel = c.bdSel;
        for (int r = 0; r < rows; r++) for (int cc = 0; cc < cols; cc++) {
            int idx = (r + gridScroll) * cols + cc;
            if (idx >= shown.size()) break;
            Block b = shown.get(idx);
            int bx = x + 8 + cc * cell, by = gy + r * rowH;
            boolean on = Registries.BLOCK.getId(b).getPath().equals(sel);
            ctx.fill(bx, by, bx + cell - 3, by + cell - 3, on ? 0xFF3A1A1E : CARD);
            if (on) { ctx.fill(bx, by, bx + cell - 3, by + 1, RED); ctx.fill(bx, by + cell - 4, bx + cell - 3, by + cell - 3, RED); ctx.fill(bx, by, bx + 1, by + cell - 3, RED); ctx.fill(bx + cell - 4, by, bx + cell - 3, by + cell - 3, RED); }
            ModIcons.draw(ctx, b.asItem(), bx + (cell - 3 - 16) / 2, by + (cell - 3 - 16) / 2, 1f);
            var ms = ctx.getMatrices(); ms.push(); ms.translate(bx, by + cell - 2, 0); ms.scale(0.6f, 0.6f, 1f);
            ctx.drawText(tr, tr.trimToWidth(b.getName().getString(), (int) ((cell - 3) / 0.6f)), 0, 0, DIM, false);
            ms.pop();
            String id = Registries.BLOCK.getId(b).getPath();
            hit(bx, by, cell - 3, cell - 3, () -> { c.bdSel = id; Config.save(); });
        }
        ctx.disableScissor();
        gridArea = new int[]{x, gy, w, gh};
        // thẻ block đã chọn
        Block s = selected();
        int cy2 = y + h - 58;
        ctx.fill(x + 6, cy2, x + w - 6, y + h - 6, CARD);
        ModIcons.draw(ctx, s.asItem(), x + 12, cy2 + 6, 2f);
        int need = Builder.need(s), have = Builder.have(s);
        ctx.drawText(tr, "§7Đã chọn", x + 52, cy2 + 5, DIM, false);
        ctx.drawText(tr, "§l" + tr.trimToWidth(s.getName().getString(), w - 62), x + 52, cy2 + 16, 0xFFFFFFFF, false);
        ctx.drawText(tr, Registries.BLOCK.getId(s).getPath() + " · " + need + " khối cần", x + 52, cy2 + 27, DIM, false);
        ctx.drawText(tr, "Trong kho: " + have + " / " + need, x + 52, cy2 + 37, have >= need ? 0xFF4CD964 : 0xFFFF6B6B, false);
        boolean inList = c.bdList.contains(Registries.BLOCK.getId(s).getPath());
        btn(ctx, x + 12, y + h - 20, w - 24, 12, inList ? "Bỏ khỏi danh sách" : "Thêm vào danh sách", RED, mx, my);
        hit(x + 12, y + h - 20, w - 24, 12, () -> { String id = Registries.BLOCK.getId(s).getPath(); if (!c.bdList.remove(id)) c.bdList.add(id); Config.save(); });
    }
    int[] gridArea = new int[]{0, 0, 0, 0}, matArea = new int[]{0, 0, 0, 0}, layerArea = new int[]{0, 0, 0, 0};

    // ----- cột 2: bảng màu -----
    void drawColors(DrawContext ctx, int x, int y, int w, int h, int mx, int my) {
        Config c = Config.I; TextRenderer tr = textRenderer;
        panel(ctx, x, y, w, h, "Bảng màu");
        String[] tn = {"Ghost", "Viền chunk"};
        int tx = x + 8;
        for (int i = 0; i < 2; i++) {
            int tw = tr.getWidth(tn[i]) + 10, ii = i;
            ctx.fill(tx, y + 20, tx + tw, y + 32, colorTarget == i ? RED : CARD);
            ctx.drawText(tr, tn[i], tx + 5, y + 22, TXT, false);
            hit(tx, y + 20, tw, 12, () -> { colorTarget = ii; loadTarget(); });
            tx += tw + 4;
        }
        int sq = Math.max(50, Math.min(w - 16, 96)), sx = x + 8, sy = y + 38;
        for (int i = 0; i < sq; i += 2) {                                   // ô S-V: mỗi cột là 1 dải từ màu sáng xuống đen
            float s = i / (float) (sq - 1);
            ctx.fillGradient(sx + i, sy, sx + Math.min(sq, i + 2), sy + sq, 0xFF000000 | hsv2rgb(hh, s, 1f), 0xFF000000);
        }
        int px = sx + (int) (hs * (sq - 1)), py = sy + (int) ((1 - hv) * (sq - 1));
        ctx.fill(px - 3, py - 3, px + 4, py + 4, 0xFFFFFFFF); ctx.fill(px - 2, py - 2, px + 3, py + 3, 0xFF000000 | curColor());
        drag(sx, sy, sq, sq, (fx, fy) -> { hs = (float) Math.max(0, Math.min(1, fx)); hv = (float) (1 - Math.max(0, Math.min(1, fy))); setColor(hsv2rgb(hh, hs, hv), true); });
        int hy = sy + sq + 5;
        for (int i = 0; i < sq; i += 2) ctx.fill(sx + i, hy, sx + Math.min(sq, i + 2), hy + 9, 0xFF000000 | hsv2rgb(i / (float) sq, 1, 1));
        int hx = sx + (int) (hh * (sq - 1));
        ctx.fill(hx - 1, hy - 1, hx + 2, hy + 10, 0xFFFFFFFF);
        drag(sx, hy, sq, 9, (fx, fy) -> { hh = (float) Math.max(0, Math.min(0.999, fx)); setColor(hsv2rgb(hh, hs, hv), true); });
        int ey = hy + 14;
        hex.visible = true; hex.setX(x + 8); hex.setY(ey); hex.setWidth(Math.min(64, w - 40));
        ctx.fill(x + 8 + hex.getWidth() + 4, ey, x + 8 + hex.getWidth() + 24, ey + 14, 0xFF000000 | curColor());
        int sy2 = ey + 20, sw = Math.max(8, Math.min(14, (w - 16) / 10 - 2));
        for (int i = 0; i < SWATCH.length; i++) {
            int bx = x + 8 + i * (sw + 2), col = SWATCH[i];
            if (bx + sw > x + w - 4) break;
            ctx.fill(bx, sy2, bx + sw, sy2 + sw, 0xFF000000 | col);
            hit(bx, sy2, sw, sw, () -> { setColor(col, true); });
        }
        int ay = sy2 + sw + 10;
        ctx.drawText(tr, "Độ mờ ghost", x + 8, ay, TXT, false);
        String as = c.bdAlpha + "%"; ctx.drawText(tr, as, x + w - 8 - tr.getWidth(as), ay, DIM, false);
        slider(ctx, x + 8, ay + 11, w - 16, c.bdAlpha / 100.0, f -> c.bdAlpha = (int) Math.round(f * 100));
        int ty = ay + 28;
        ctx.drawText(tr, "Độ dày viền", x + 8, ty, TXT, false);
        String ts = c.bdThick + " px"; ctx.drawText(tr, ts, x + w - 8 - tr.getWidth(ts), ty, DIM, false);
        slider(ctx, x + 8, ty + 11, w - 16, (c.bdThick - 1) / 5.0, f -> c.bdThick = 1 + (int) Math.round(f * 5));
        btn(ctx, x + 8, y + h - 20, w - 16, 12, "Đặt lại màu mặc định", CARD, mx, my);
        hit(x + 8, y + h - 20, w - 16, 12, () -> { c.bdGhostColor = 0xE0262E; c.bdChunkColor = 0xFFC83C; c.bdAlpha = 60; c.bdThick = 2; loadTarget(); });
    }

    // ----- cột 3: thông tin dựng -----
    void drawInfo(DrawContext ctx, int x, int y, int w, int h, int mx, int my) {
        Config c = Config.I; TextRenderer tr = textRenderer;
        panel(ctx, x, y, w, h, "Thông tin dựng");
        String file = Printer.loadedName == null ? "(chưa nạp schematic)" : Printer.loadedName;
        ctx.fill(x + 8, y + 20, x + w - 8, y + 32, CARD);
        ctx.drawText(tr, "Nạp: " + tr.trimToWidth(file, w - 50), x + 12, y + 22, TXT, false);
        ctx.drawText(tr, "▸", x + w - 16, y + 22, RED, false);
        hit(x + 8, y + 20, w - 16, 12, () -> {                               // bấm để chuyển sang file .litematic kế tiếp
            List<String> fs = Printer.list();
            if (fs.isEmpty()) { Util.warn("Chưa có file .litematic trong thư mục schematics"); return; }
            int i = Printer.loadedName == null ? -1 : fs.indexOf(Printer.loadedName);
            try { Printer.load(fs.get((i + 1) % fs.size())); c.bdLayer = 0; Util.msg("Đã nạp " + Printer.loadedName + " (" + Printer.blocks.size() + " block)"); }
            catch (Exception e) { Util.warn("Không nạp được: " + e.getMessage()); }
        });
        int N = Builder.layers();
        int ly = y + 38;
        ctx.drawText(tr, "Lớp", x + 8, ly, DIM, false);
        String lt = N == 0 ? "-" : (c.bdLayer == 0 ? "Tất cả" : c.bdLayer + " / " + N);
        ctx.drawText(tr, "§l" + lt, x + w - 8 - tr.getWidth(lt), ly, TXT, false);
        if (N > 0) slider(ctx, x + 8, ly + 11, w - 16, c.bdLayer / (double) N, f -> c.bdLayer = (int) Math.round(f * N));
        layerArea = new int[]{x, ly, w, 24};
        int by = ly + 26;
        btn(ctx, x + 8, by, 24, 12, "◀", CARD, mx, my); hit(x + 8, by, 24, 12, () -> c.bdLayer = Math.max(0, c.bdLayer - 1));
        btn(ctx, x + w - 32, by, 24, 12, "▶", CARD, mx, my); hit(x + w - 32, by, 24, 12, () -> c.bdLayer = Math.min(N, c.bdLayer + 1));
        ctx.drawCenteredTextWithShadow(tr, "§7Cuộn để đổi lớp", x + w / 2, by + 2, DIM);
        int ty = by + 20;
        String[] lb = {"Vẽ khung ghost block", "Viền chunk", "Ẩn block đã đặt", "Báo thiếu vật liệu", "Chỉ vẽ block trong danh sách"};
        for (int i = 0; i < lb.length; i++) {
            boolean on = switch (i) { case 0 -> c.bdGhost; case 1 -> c.bdChunk; case 2 -> c.bdHide; case 3 -> c.bdWarn; default -> c.bdListOnly; };
            ctx.drawText(tr, tr.trimToWidth(lb[i], w - 46), x + 8, ty + i * 15 + 1, TXT, false);
            pill(ctx, x + w - 30, ty + i * 15, on);
            int ii = i;
            hit(x + 8, ty + i * 15 - 2, w - 16, 14, () -> { switch (ii) { case 0 -> c.bdGhost = !c.bdGhost; case 1 -> c.bdChunk = !c.bdChunk; case 2 -> c.bdHide = !c.bdHide; case 3 -> c.bdWarn = !c.bdWarn; default -> c.bdListOnly = !c.bdListOnly; } });
        }
        int my0 = ty + lb.length * 15 + 4;
        ctx.drawText(tr, "Vật liệu", x + 8, my0, DIM, false);
        ctx.drawText(tr, "Cần", x + w - 90, my0, DIM, false); ctx.drawText(tr, "Có", x + w - 56, my0, DIM, false); ctx.drawText(tr, "Thiếu", x + w - 30, my0, DIM, false);
        int rowH = 11, tableTop = my0 + 11, tableBottom = y + h - 54;
        List<Builder.Mat> mats = Builder.materials();
        int rows = Math.max(1, (tableBottom - tableTop) / rowH);
        matScroll = Math.max(0, Math.min(Math.max(0, mats.size() - rows), matScroll));
        matArea = new int[]{x, tableTop, w, tableBottom - tableTop};
        for (int i = 0; i < rows && i + matScroll < mats.size(); i++) {
            Builder.Mat mt = mats.get(i + matScroll);
            int ry = tableTop + i * rowH;
            ctx.drawText(tr, tr.trimToWidth(mt.block().getName().getString(), w - 100), x + 8, ry, TXT, false);
            ctx.drawText(tr, "" + mt.need(), x + w - 90, ry, DIM, false);
            ctx.drawText(tr, "" + mt.have(), x + w - 56, ry, DIM, false);
            ctx.drawText(tr, "" + mt.miss(), x + w - 30, ry, mt.miss() > 0 ? 0xFFFF5555 : 0xFF4CD964, false);
        }
        int sy = y + h - 50, miss = Builder.missingTypes();
        ctx.fill(x + 6, sy, x + w - 6, sy + 24, CARD);
        if (N == 0) ctx.drawText(tr, "§7Chưa nạp schematic", x + 12, sy + 8, DIM, false);
        else if (miss == 0) ctx.drawText(tr, "§aĐủ vật liệu", x + 12, sy + 8, 0xFF4CD964, false);
        else {
            ctx.drawText(tr, "§cCòn thiếu " + miss + " loại vật liệu", x + 12, sy + 4, 0xFFFF5555, false);
            var m0 = mats.get(0);
            ctx.drawText(tr, tr.trimToWidth("Cần thêm " + m0.miss() + " " + m0.block().getName().getString(), w - 24), x + 12, sy + 14, DIM, false);
        }
        btn(ctx, x + 8, y + h - 20, w - 16, 12, "Xuất danh sách vật liệu", CARD, mx, my);
        hit(x + 8, y + h - 20, w - 16, 12, Builder::export);
    }

    // ---------- chuột ----------
    @Override public boolean mouseClicked(double mx, double my, int b) {
        if (super.mouseClicked(mx, my, b)) return true;
        if (b == 1) { close(); return true; }
        for (int i = drags.size() - 1; i >= 0; i--) {
            Object[] o = drags.get(i);
            if (in(o, mx, my)) { activeDrag = (BiConsumer<Double, Double>) o[4]; dragRect = new int[]{(int) o[0], (int) o[1], (int) o[2], (int) o[3]}; activeDrag.accept((mx - dragRect[0]) / dragRect[2], (my - dragRect[1]) / dragRect[3]); return true; }
        }
        for (int i = hits.size() - 1; i >= 0; i--) { Object[] o = hits.get(i); if (in(o, mx, my)) { ((Runnable) o[4]).run(); Config.save(); return true; } }
        return false;
    }

    @Override public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
        if (activeDrag != null) { activeDrag.accept((mx - dragRect[0]) / dragRect[2], (my - dragRect[1]) / dragRect[3]); return true; }
        return super.mouseDragged(mx, my, b, dx, dy);
    }

    @Override public boolean mouseReleased(double mx, double my, int b) {
        if (activeDrag != null) { activeDrag = null; Config.save(); return true; }
        return super.mouseReleased(mx, my, b);
    }

    @Override public boolean mouseScrolled(double mx, double my, double h, double v) {
        int dir = v > 0 ? -1 : 1;
        if (mx >= gridArea[0] && mx < gridArea[0] + gridArea[2] && my >= gridArea[1] && my < gridArea[1] + gridArea[3]) { gridScroll += dir; return true; }
        if (mx >= matArea[0] && mx < matArea[0] + matArea[2] && my >= matArea[1] && my < matArea[1] + matArea[3]) { matScroll += dir; return true; }
        int N = Builder.layers();
        if (N > 0) { Config.I.bdLayer = Math.max(0, Math.min(N, Config.I.bdLayer - dir)); Config.save(); return true; }
        return super.mouseScrolled(mx, my, h, v);
    }

    @Override public void removed() { Config.save(); }
    @Override public void close() { MinecraftClient.getInstance().setScreen(parent); }
}
