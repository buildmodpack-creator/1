package com.safeanchor;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.nio.file.Files;
import java.util.*;

/**
 * Builder "Xây dựng cơ sở": dùng schematic .litematic đã nạp trong Printer.
 * Vẽ khung ghost block theo từng lớp, viền chunk, bảng vật liệu Cần / Có / Thiếu, báo thiếu vật liệu, xuất danh sách vật liệu.
 * Chỉ hiển thị, không tự thao tác. Thoát sớm khi module tắt.
 */
public class Builder {
    public record Mat(Block block, int need, int have) { public int miss() { return Math.max(0, need - have); } }

    static Map<Long, BlockState> cacheFor;
    static int minY, maxY;                         // y tương đối của schematic
    static final Map<Block, Integer> counts = new HashMap<>();
    static final Map<Integer, List<Long>> byLayer = new HashMap<>();
    static List<Box> ghost = new ArrayList<>();
    static long lastBuild = -100;
    static List<Mat> matCache = new ArrayList<>(); static long lastMat = -100;

    static void ensure() {
        if (cacheFor == Printer.blocks) return;
        cacheFor = Printer.blocks;
        counts.clear(); byLayer.clear(); ghost = new ArrayList<>(); lastBuild = -100; lastMat = -100;
        minY = Integer.MAX_VALUE; maxY = Integer.MIN_VALUE;
        for (var e : Printer.blocks.entrySet()) {
            BlockPos p = BlockPos.fromLong(e.getKey());
            minY = Math.min(minY, p.getY()); maxY = Math.max(maxY, p.getY());
            counts.merge(e.getValue().getBlock(), 1, Integer::sum);
        }
        for (long k : Printer.blocks.keySet()) byLayer.computeIfAbsent(BlockPos.fromLong(k).getY() - minY + 1, z -> new ArrayList<>()).add(k);
        if (Printer.blocks.isEmpty()) { minY = 0; maxY = -1; }
    }

    public static int layers() { ensure(); return Math.max(0, maxY - minY + 1); }
    public static boolean loaded() { return !Printer.blocks.isEmpty() && Printer.origin != null; }

    public static int have(Block b) {
        var p = MinecraftClient.getInstance().player;
        if (p == null) return 0;
        Item it = b.asItem();
        if (it == Items.AIR) return 0;
        PlayerInventory inv = p.getInventory();
        int n = 0;
        for (int i = 0; i < inv.size(); i++) { ItemStack s = inv.getStack(i); if (s.isOf(it)) n += s.getCount(); }
        return n;
    }

    public static int need(Block b) { ensure(); return counts.getOrDefault(b, 0); }

    /** Bảng vật liệu: thiếu nhiều nhất lên đầu. */
    public static List<Mat> materials() {
        ensure();
        var mc = MinecraftClient.getInstance();
        long now = mc.world == null ? 0 : mc.world.getTime();
        if (now - lastMat < 10 && now >= lastMat) return matCache;
        lastMat = now;
        List<Mat> out = new ArrayList<>();
        for (var e : counts.entrySet()) if (e.getKey().asItem() != Items.AIR) out.add(new Mat(e.getKey(), e.getValue(), have(e.getKey())));
        out.sort(Comparator.comparingInt((Mat m) -> -m.miss()).thenComparing(m -> Registries.BLOCK.getId(m.block()).getPath()));
        matCache = out;
        return out;
    }

    public static int missingTypes() { int n = 0; for (Mat m : materials()) if (m.miss() > 0) n++; return n; }

    // ---------- vẽ ghost + viền chunk ----------
    public static void render(WorldRenderContext ctx) {
        Config c = Config.I;
        if (!c.bdOn || !c.enabled || !loaded()) return;
        var mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        ensure();
        List<BaseScan.Draw> list = new ArrayList<>();
        int a = Math.max(5, Math.min(255, (int) (c.bdAlpha * 2.55 * 0.6)));

        if (c.bdGhost) {
            long now = mc.world.getTime();
            if (now - lastBuild >= 10 || now < lastBuild) {
                lastBuild = now;
                List<Box> g = new ArrayList<>();
                List<Long> src = new ArrayList<>();
                if (c.bdLayer > 0) { var l = byLayer.get(c.bdLayer); if (l != null) src = l; }
                else for (var l : byLayer.values()) src.addAll(l);
                Vec3d pp = mc.player.getPos();
                boolean only = c.bdListOnly && !c.bdList.isEmpty();
                for (long k : src) {
                    BlockPos q = BlockPos.fromLong(k).add(Printer.origin);
                    if (q.getSquaredDistance(pp.x, pp.y, pp.z) > 48 * 48) continue;
                    BlockState want = Printer.blocks.get(k);
                    if (want == null) continue;
                    if (only && !c.bdList.contains(Registries.BLOCK.getId(want.getBlock()).getPath())) continue;
                    if (c.bdHide && mc.world.getBlockState(q).isOf(want.getBlock())) continue;       // ẩn block đã đặt đúng
                    g.add(new Box(q));
                    if (g.size() >= 3000) break;
                }
                ghost = g;
            }
            for (Box b : ghost) list.add(new BaseScan.Draw(b, c.bdGhostColor, a));
        }
        if (c.bdChunk) {                                                    // viền chunk quanh khu xây
            int x0 = Integer.MAX_VALUE, x1 = Integer.MIN_VALUE, z0 = Integer.MAX_VALUE, z1 = Integer.MIN_VALUE;
            for (long k : Printer.blocks.keySet()) { BlockPos p = BlockPos.fromLong(k); x0 = Math.min(x0, p.getX()); x1 = Math.max(x1, p.getX()); z0 = Math.min(z0, p.getZ()); z1 = Math.max(z1, p.getZ()); }
            int ox = Printer.origin.getX(), oy = Printer.origin.getY(), oz = Printer.origin.getZ();
            int cx0 = (x0 + ox) >> 4, cx1 = (x1 + ox) >> 4, cz0 = (z0 + oz) >> 4, cz1 = (z1 + oz) >> 4;
            for (int cx = cx0; cx <= cx1 && list.size() < 5000; cx++) for (int cz = cz0; cz <= cz1; cz++)
                list.add(new BaseScan.Draw(new Box(cx * 16, minY + oy, cz * 16, cx * 16 + 16, maxY + oy + 1, cz * 16 + 16), c.bdChunkColor, 0));
        }
        BaseScan.paint(ctx, list, Math.max(1f, c.bdThick));
    }

    // ---------- báo thiếu vật liệu ----------
    public static void hud(DrawContext ctx) {
        Config c = Config.I;
        if (!c.bdOn || !c.bdWarn || !c.enabled || !loaded()) return;
        var mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        int n = missingTypes();
        if (n <= 0) return;
        var m = materials().get(0);
        String t = "Thiếu " + n + " loại vật liệu - nhiều nhất: " + m.block().getName().getString() + " x" + m.miss();
        int w = mc.textRenderer.getWidth(t), x = (mc.getWindow().getScaledWidth() - w) / 2;
        ctx.fill(x - 4, 36, x + w + 4, 49, 0x90000000);
        ctx.drawText(mc.textRenderer, t, x, 39, 0xFFFF5555, true);
    }

    // ---------- xuất danh sách vật liệu ----------
    public static void export() {
        try {
            var f = FabricLoader.getInstance().getConfigDir().resolve("lananh-materials.txt");
            StringBuilder sb = new StringBuilder("Vật liệu cho " + (Printer.loadedName == null ? "(chưa nạp)" : Printer.loadedName) + "\n");
            sb.append(String.format("%-32s %7s %7s %7s%n", "Block", "Cần", "Có", "Thiếu"));
            for (Mat m : materials()) sb.append(String.format("%-32s %7d %7d %7d%n", m.block().getName().getString(), m.need(), m.have(), m.miss()));
            Files.writeString(f, sb.toString());
            Util.msg("Đã xuất danh sách vật liệu: config/lananh-materials.txt");
        } catch (Exception e) { Util.warn("Không xuất được: " + e.getMessage()); }
    }
}
